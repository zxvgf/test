import asyncio  
import websockets  
import json  
  
async def hello(uri):  
    async with websockets.connect(uri) as websocket:  
        # 发送初始的JSON消息到服务器  
        initial_message = {"image": "",  
                           "nameList": "鼓风机",  
                           "question": "结构图",
                           "session_id":""}  
        await websocket.send(json.dumps(initial_message))  
  
        # 接收并打印从服务器发送的每个JSON消息  
        async for message in websocket:  
            data = json.loads(message)  
            print(f"Received from server: {data}")  
  
# WebSocket服务器的URI  
uri = "ws://47.120.12.240:9008"  
# uri = "ws://127.0.0.1:9008"  
  
# 运行客户端的异步事件循环  
asyncio.get_event_loop().run_until_complete(hello(uri))

try:
    pass
except Exception as e:
    pass