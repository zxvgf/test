from http import HTTPStatus
from dashscope import Application


def call_agent_app():
    response = Application.call(app_id='299687aca7e5406db9d622f8d659e7f7',
                                prompt='Introduce the capital of China',
                                )

    if response.status_code != HTTPStatus.OK:
        print('request_id=%s, code=%s, message=%s\n' % (response.request_id, response.status_code, response.message))
    else:
        print('request_id=%s\n output=%s\n usage=%s\n' % (response.request_id, response.output, response.usage))


if __name__ == '__main__':
    call_agent_app()