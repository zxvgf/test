from dashscope import Generation
from dashscope import Application
import datetime
from API_KEY_ZHOU import API_KEY



def write_outline(question,session_id=None):
    rsp = Application.call(app_id='ccccccc', prompt=question,stream=True,api_key=API_KEY)
    return rsp

def write_body(outline,writePart,session_id):
    prompt=f"""
    小说大纲如下所示：
    {outline}
    编写以下内容相关的部分：
    {writePart}
    """
    rsp = Application.call(app_id='aaaaaaaaa', prompt=prompt,session_id=session_id,stream=True,api_key=API_KEY)
    return rsp

def write_title(body):
    rsp = Application.call(app_id='bbbbbb', prompt=body,stream=True,api_key=API_KEY)
    return rsp



