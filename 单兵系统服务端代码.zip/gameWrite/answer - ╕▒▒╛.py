from dashscope import Generation
from dashscope import Application
import datetime
from API_KEY_ZHOU import API_KEY



def write_outline(question,session_id=None):
    rsp = Application.call(app_id='462424eae40d482d9d71800ade6cddfc', prompt=question,stream=True,api_key=API_KEY)
    return rsp

def write_body(outline,writePart,session_id):
    prompt=f"""
    小说大纲如下所示：
    {outline}
    编写以下内容相关的部分：
    {writePart}
    """
    rsp = Application.call(app_id='85e8e19327ae4b9ca37e3520e9c503a4', prompt=prompt,session_id=session_id,stream=True,api_key=API_KEY)
    return rsp

def write_title(body):
    rsp = Application.call(app_id='8d599621861a446784d3bf2e29468a77', prompt=body,stream=True,api_key=API_KEY)
    return rsp



