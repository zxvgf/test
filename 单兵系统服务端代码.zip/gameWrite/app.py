from answer import *

from API_KEY_ZHOU import API_KEY
import dashscope
from dashtext import SparseVectorEncoder
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

import json,time
from flask import jsonify
import asyncio
import json
from http import HTTPStatus

app = FastAPI()
dashscope.api_key = API_KEY


def createJson(id, isBody, text, status):
    data = {
            "textid": id,
            "isBody": isBody,
            "text": text,
            "status": status,
        }
    return data

def getContent(data):
    return data["output"]["text"]

class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def send_personal_message(self, message, websocket: WebSocket):
        await websocket.send_json(message)
    
    async def send_personal_txt(self, message: str, websocket: WebSocket):
        await websocket.send_text(message)

    async def broadcast(self, message: str):
        for connection in self.active_connections:
            await connection.send_text(message)

#链接控制器
manager = ConnectionManager()

#主体
@app.websocket("/ws/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: int):
    await manager.connect(websocket)
    #客户端链接成功
    print(client_id," has connected")
    
    #客户端循环异步任务句柄
    async def handle_client(websocket: WebSocket, client_id: int):
        print("recive ...")
        #循环消息
        async for message in websocket.iter_text():
            print(f"Received from client {client_id}: {message}")
            data_dict = json.loads(message)
            question = data_dict["question"]

            """
            write_title:标题生成函数，调用阿里云上发布的智能体，返回responses，智能体中的提示词如下：
                你是一名专业游戏题材小说作家，你需要根据以下的关键词写出一个简要的小说描述文本以及小说的标题。字数在200字以内。
                -body:用户给出的关键词字符串
            """
            responses = write_title(question)
            #模型状态
            status="wait"
            #存储模型生成的文本
            title=""
            #流式会话的ID
            myID=0
            #流式会话
            for res in responses:
                #获取模型输出的流式结果
                title=res.output.text
                #打印结果
                print(title)
                #构建json
                data = createJson(myID, False, title, status)
                #发送json
                await ConnectionManager().send_personal_message(data, websocket)
                await asyncio.sleep(0.05)  # 避免紧密循环，可以调整为更合适的值
            
            question=title
            # 打印模型根据关键词生成的小说描述文本
            print(question)
            
            try:
                """
                write_outline:大纲生成函数，调用阿里云上发布的智能体，返回responses，智能体中的提示词如下：
                    你是一名专门编写游戏题材小说的职业作家，你需要根据用户给出的小说描述生成与游戏相关的小说的大纲，并设计主体情节以及主角和配角的名称。
                    注意：
                    （1）大纲应包括小说的所有要素内容，如小说名称、故事背景、主要角色、每一章节的标题。
                    （2）小说预计内容在一万字以上，请给出可以满足字数的小说大纲。
                    （3）大纲的每一章内容之间用##**##分割，例如：
                    故事背景
                    ##**##
                    第一章：起源
                    ##**##
                    第二章
                -question:给模型用于生成大纲的小说简要描述文本
                -session_id:大模型多轮对话的会话ID
                """
                responses = write_outline(question)
                #模型生成状态
                status="ok"
                #流式回复
                for res in responses:
                    #获取模型的回复结果
                    outline=res.output.text
                    print(outline)
                    #创建json
                    data = createJson(myID, False, outline, status)
                    #发送json
                    await ConnectionManager().send_personal_message(data, websocket)
                    await asyncio.sleep(0.05)  # 避免紧密循环，可以调整为更合适的值
                    myID+=1
                print("===========大纲生成完成=============")
                print(outline)
                #将模型生成的大纲按照章节分割
                outlineList=outline.split("##**##")
                #用于多轮对话的阿里云大模型对话ID
                session_id=""
                #####小说最终内容#######
                finalText=title+"\n"
                Num=1
                try:
                    #循环每一个章节的大纲，为每一个章节生成小说内容
                    for bodyPart in outlineList[1:]:
                        print("当前章节：",Num,"bodypart:",bodyPart)
                        """
                        write_body:小说内容生成函数，调用阿里云上发布的智能体，返回responses，智能体中的提示词如下：
                            你是一名编写游戏题材小说的职业作家，你需要根据以下的大纲、关键词、主体情节，编写小说的对应章节内容。
                            注意：
                            （1）只需要生成用户指定的章节对应的内容即可。
                            （1）需要你充分描绘人物的对话以及心理活动，让读者可以身临其境。
                            （2）刻画人物形象时，应尽量细节。
                            （3）如果有描绘战斗场面的章节，尽量刻画的更加细节。
                            （4）章节的字数应该在4000字左右。
                            （5）需要你发挥想象力。
                            （6）直接输出小说内容。
                        -outline:大纲全部内容
                        -writePart:当前章节的大纲内容
                        -session_id:大模型多轮对话的会话ID
                        """
                        responses = write_body(question,f"第{Num}章"+bodyPart,session_id)
                        bodyOutPut=""
                        #大模型的流式回复
                        for res in responses:
                            #获取回复结果
                            bodyOutPut=res.output.text
                            #创建json
                            data = createJson(myID, True, finalText+bodyOutPut, status)
                            #发送json
                            await ConnectionManager().send_personal_message(data, websocket)
                            await asyncio.sleep(0.05)  # 避免紧密循环，可以调整为更合适的值
                        #叠加每一轮大模型的输出
                        finalText+=bodyOutPut
                        Num+=1   
                    print(finalText)             
                except Exception as e:
                    print(e)
                    status="error"
                    return jsonify({'status': 'error', 'message': 'Data received'}), 200
                
            except json.JSONDecodeError as e:
                # 如果 JSON 解析失败，可以处理异常或返回错误响应
                data = {
                    "Error": "Invalid JSON data"
                }
                return jsonify({'status': 'error', 'message': 'Data received'}), 200
        # 为当前客户端创建一个异步任务来处理其消息

    await asyncio.create_task(handle_client(websocket, client_id))
    try:
        # 保持连接打开，直到发生异常（如客户端断开连接）
        await asyncio.Future()  # 这是一个永远不会完成的Future，用于保持协程运行
    except WebSocketDisconnect:
        await ConnectionManager().disconnect(websocket)
        print(f"Client {client_id} disconnected")
        await ConnectionManager().broadcast(f"Client #{client_id} left the chat")

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=9008)

