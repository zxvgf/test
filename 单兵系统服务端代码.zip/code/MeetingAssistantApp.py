
from answer import *
from API_KEY import API_KEY
import dashscope
import json
from flask import Flask, request, jsonify, make_response 
from flask_cors import CORS 
dashscope.api_key = API_KEY

def textToAnswer(quesiton):
        head=""
        result=""
        try:
            result=answer_question_MeetingAssistant(quesiton)
        except Exception as e:
            print(e)
            head="#error#"
        return result,head

def textToAnswer_summary(quesiton):
        head=""
        result=""
        try:
            result=answer_question_Summary(quesiton)
        except Exception as e:
            print(e)
            head="#error#"
        return result,head

def textToAnswer_day(quesiton):
        head=""
        result=""
        try:
            result=answer_question_DayWeek(quesiton)
        except Exception as e:
            print(e)
            head="#error#"
        return result,head

def textToAnswer_process(quesiton):
        head=""
        result=""
        try:
            result=answer_question_process(quesiton)
        except Exception as e:
            print(e)
            head="#error#"
        return result,head

app = Flask(__name__)  # 确保使用正确的Flask实例名称  
CORS(app, resources={r"/*": {"origins": "*"}})  
  
def cors_headers(origins=('*',)):  # 默认为所有源，使用元组来存储允许的源  
    """  
    CORS 装饰器，允许跨域请求。  
    :param origins: 允许的源地址列表，默认为 '*'（所有源）。  
    """  
    def decorator(f):  
        def wrapped_function(*args, **kwargs):  
            resp = make_response(f(*args, **kwargs))  # 先调用函数，再创建响应 
            print("resp:",resp) 
            print("ttt:",request.headers.get('Origin'))
            if '*' in origins or request.headers.get('Origin') in origins:  
                print(request.headers.get('Origin', '*'))
                resp.headers['Access-Control-Allow-Origin'] = request.headers.get('Origin', '*')  
            else:  
                resp.status_code = 403  
                print("error 403")
                return resp  
  
            # 其他 CORS 头部  
            resp.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'  
            resp.headers['Access-Control-Allow-Headers'] = 'Content-Type, Authorization'  
  
            # 对于预检请求，直接返回（不执行函数体）  
            if request.method == 'OPTIONS':  
                return resp  
  
            return resp  
        return wrapped_function  
    return decorator  
  
# renWuKa
@app.route('/MeetingAssistant', methods=['POST'])  
# @cors_headers(['http://192.168.2.248:9528','http://localhost:9528'])
def post_data_json():  
    if request.is_json:  
        try:  
            data_dict = request.get_json()
            question=data_dict["question"]

            answer,head = textToAnswer(question)
            print("answer:",answer)
            # 这里可以处理大模型返回的数据 
            data = {  
                "answer": answer,  
                "head":head
            }  
            return jsonify(data), 200 
        except json.JSONDecodeError as e:  
            # 如果 JSON 解析失败，可以处理异常或返回错误响应  
            data = {  
            "Error": "Invalid JSON data"  
            }  
            return jsonify({'status': 'error', 'message': 'Data received'}), 200 
    else:  
        return jsonify({'status': 'error', 'message': 'Invalid payload'}), 400

#huiyizongjie
@app.route('/Summary', methods=['POST'])  
# @cors_headers(['http://192.168.2.248:9528','http://localhost:9528'])
def post_data_json2():  
    if request.is_json:  
        try:  
            data_dict = request.get_json()
            question=data_dict["question"]

            answer,head = textToAnswer_summary(question)
            print("answer:",answer)
            # 这里可以处理大模型返回的数据 
            data = {  
                "answer": answer,  
                "head":head
            }  
            return jsonify(data), 200 
        except json.JSONDecodeError as e:  
            # 如果 JSON 解析失败，可以处理异常或返回错误响应  
            data = {  
            "Error": "Invalid JSON data"  
            }  
            return jsonify({'status': 'error', 'message': 'Data received'}), 200 
    else:  
        return jsonify({'status': 'error', 'message': 'Invalid payload'}), 400

@app.route('/Day', methods=['POST'])  
# @cors_headers(['http://192.168.2.248:9528','http://localhost:9528'])
def post_data_json3():  
    if request.is_json:  
        try:  
            data_dict = request.get_json()
            question=data_dict["question"]

            answer,head = textToAnswer_day(question)
            print("answer:",answer)
            # 这里可以处理大模型返回的数据 
            data = {  
                "answer": answer,  
                "head":head
            }  
            return jsonify(data), 200 
        except json.JSONDecodeError as e:  
            # 如果 JSON 解析失败，可以处理异常或返回错误响应  
            data = {  
            "Error": "Invalid JSON data"  
            }  
            return jsonify({'status': 'error', 'message': 'Data received'}), 200 
    else:  
        return jsonify({'status': 'error', 'message': 'Invalid payload'}), 400
    
@app.route('/process', methods=['POST'])  
# @cors_headers(['http://192.168.2.248:9528','http://localhost:9528'])
def post_data_json4():  
    if request.is_json:  
        try:  
            data_dict = request.get_json()
            question=data_dict["question"]

            answer,head = textToAnswer_process(question)
            print("answer:",answer)
            # 这里可以处理大模型返回的数据 
            data = {  
                "answer": answer,  
                "head":head
            }  
            return jsonify(data), 200 
        except json.JSONDecodeError as e:  
            # 如果 JSON 解析失败，可以处理异常或返回错误响应  
            data = {  
            "Error": "Invalid JSON data"  
            }  
            return jsonify({'status': 'error', 'message': 'Data received'}), 200 
    else:  
        return jsonify({'status': 'error', 'message': 'Invalid payload'}), 400

def getContent(data):
    return data["output"]["choices"][0]["message"]["content"]

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

##### gunicorn --workers=2 --bind=0.0.0.0:8000 app:app #####
