
STATUS_FIRST_FRAME = 0  # 第一帧的标识
STATUS_CONTINUE_FRAME = 1  # 中间帧标识
STATUS_LAST_FRAME = 2  # 最后一帧的标识
#MP3音频格式
AUDIO_TYPE="lame"   #raw
#说话人物
CHARACTER="aisjiuxu"
#文件名
AnswerFileName='BigModelDemo/WebFiles/MP3File/answer.mp3'

WAVE_OUTPUT_FILENAME = "BigModelDemo/WebFiles/MP3File/output.wav"  
QuestionFileName = "BigModelDemo/WebFiles/MP3File/question.mp3"   
TEXT_COLLECTION_NAME="news_embedings"
PHOTO_COLLECTION_NAME="photo_embedings"

# （全部）自有语料
CORPUS = [
    "油站结构图",
    "安全防护用品穿戴图",
    "消防及逃生安全疏散图",
    "岗位卫生区划分图",
    "煤气检测仪示意图",
    "风机油泵操作台图",
    "鼓风机的工艺流程图",
    "空气呼吸器示意图",
    "鼓风机的结构图",
]