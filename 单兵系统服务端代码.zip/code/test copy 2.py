from openai import OpenAI

import time
client = OpenAI(api_key="sk-4111bf6521244b2d83d00bc616c6239e", base_url="https://api.deepseek.com")

timestart=time.time()
# Round 1
messages = [{"role": "user", "content": "介绍一下马云"}]
response = client.chat.completions.create(
    model="deepseek-chat",
    messages=messages,
    stream=True
)
# print(response)
for me in response:
    print(time.time()-timestart)
    print(me)
    break
# messages.append(response.choices[0].message)
# print(f"Messages Round 1: {messages}")

# # Round 2
# messages.append({"role": "user", "content": "雷军呢"})
# response = client.chat.completions.create(
#     model="deepseek-chat",
#     messages=messages,
#     stream=True
# )

# messages.append(response.choices[0].message)
# print(f"Messages Round 2: {messages}")