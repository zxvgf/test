from dashscope import Generation
from dashscope import Application
import dashscope
import datetime
from API_KEY import API_KEY


def photoInQuestion(context):
    prompt = f'''帮我分析一下内容中是否要求获取图片/图纸/图像等图片信息，是请回答True，否请回答False"
    ```
    {context}
    ```
    '''
    rsp = Generation.call(model='qwen-turbo', prompt=prompt)
    return rsp.output.text
def answer_question(question,session_id):
    rsp = Application.call(app_id='299687aca7e5406db9d622f8d659e7f7', prompt=question,session_id=session_id,stream=True,api_key=API_KEY,incremental_output =True)
    return rsp

def audio_control(question):
    rsp = Application.call(app_id='6056339a59334cf18241eb1f89c6a481', prompt=question,api_key=API_KEY)
    return rsp

def answer_question_MeetingAssistant(question):
    prompt = f'''
    今天的日期：{datetime.date.today()}。
    分析下面的内容：{question}。
    '''
    # rsp = Generation.call(model='qwen-turbo', prompt=prompt)
    rsp = Application.call(app_id='fba3fa2e88974a5491f4861b309041ea', prompt=prompt,api_key=API_KEY)
    return rsp.output.text

def answer_question_Summary(question):
    rsp = Application.call(app_id='39196837eb154150af2aecada4ff1cf1', prompt=question,api_key=API_KEY)
    return rsp.output.text

def answer_question_DayWeek(question):
    rsp = Application.call(app_id='f91e9097e72246d99a12262a61332f5b', prompt=question,api_key=API_KEY)
    return rsp.output.text

def answer_question_process(question):
    rsp = Application.call(app_id='565bb1e864834adca7b0f050f72fb99b', prompt=question,api_key=API_KEY)
    return rsp.output.text

def answer_question_img(question,imgURL):
    messages = [
    {
        "role": "user",
        "content": [
        {"image": imgURL},
        {"text": question}]
    }]
    rsp = Application.call(app_id='799a4ab61b154b17b2d1cabf2b49d94d', messages=messages,api_key=API_KEY,stream=True,image_list=[imgURL],incremental_output =True)
    return rsp

