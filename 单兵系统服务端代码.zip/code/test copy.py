import threading

from dashscope import Application
import time
from API_KEY import API_KEY


def answer_question(question,session_id):
    rsp = Application.call(app_id='299687aca7e5406db9d622f8d659e7f7', prompt=question,session_id=session_id,stream=True,api_key=API_KEY)
    return rsp

startTime=time.time()
rsp=answer_question("风机出口压力大幅度波动怎么办","")

for response in rsp:
    print(time.time()-startTime)
    print(response)
