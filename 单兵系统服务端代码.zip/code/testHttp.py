import asyncio  
import aiohttp  
import json  
  
async def hello(url, data):  
    async with aiohttp.ClientSession() as session:  
        async with session.post(url, json=data) as response:  
            # 读取响应内容  
            resp_data = await response.json()  
            print(f"Received from server: {resp_data}")  
  
# 服务器URL和数据  
url = "http://192.168.2.41:8087/api/admin/ai/chatAI"  
data = {  
    "message": "我脚疼",  
    "sessionId": ""  
}  
  
# 运行客户端的异步事件循环  
asyncio.get_event_loop().run_until_complete(hello(url, data))