from alibabacloud_docmind_api20220711.client import Client as docmind_api20220711Client
from alibabacloud_tea_openapi import models as open_api_models
from alibabacloud_docmind_api20220711 import models as docmind_api20220711_models
from alibabacloud_tea_util.client import Client as UtilClient
from alibabacloud_tea_util import models as util_models
from alibabacloud_credentials.client import Client as CredClient
from embedding import *


def generate_embeddings(news):
    rsp = TextEmbedding.call(
        model=TextEmbedding.Models.text_embedding_v1,
        input=news
    )
    embeddings = [record['embedding'] for record in rsp.output['embeddings']]
    return embeddings if isinstance(news, list) else embeddings[0]

def stringEmbedding(stringList,id):
    for news in stringList:
        ids = [id + i for i, _ in enumerate(news)]
        id += len(news)
        
        vectors = generate_embeddings(news)
        # 写入 dashvector 构建索引
        rsp = collection.upsert(
            [
                Doc(id=str(id), vector=vector, fields={"raw": doc})
                for id, vector, doc in zip(ids, vectors, news)
            ]
        )
        assert rsp

def getTotalNum():
    #################周英骏账户#########################
    dashscope.api_key = 'sk-23a72f7d52ad4e20aba380dcdaeb8396'
    # 初始化 dashvector client
    client = Client(
      api_key='sk-9C42cGH1LYGC80ySaius347Jiu12z5F567DB60F6211EFA1175A33F382DBD6',
      endpoint='vrs-cn-0dw41wqt00001o.dashvector.cn-beijing.aliyuncs.com'
    )
    #创建collection
    # collection=createCollection(client,textCollectionName)

    #获取collection
    collection = client.get(name=textCollectionName)
    ret = collection.stats()
    json_str=str(ret.output)
    print(json_str)
    try:
        data = json.loads(json_str)
        total_doc_count = data['total_doc_count']
        return total_doc_count
    except json.JSONDecodeError:
        print("Error decoding JSON")
        return None
    except KeyError:
        print("Error extracting total_doc_count")
        return None
    total=ret.output['total_doc_count']
    return total

if __name__ == '__main__':
  	# 使用默认凭证初始化Credentials Client。
    # cred=CredClient()
    config = open_api_models.Config(
        # 通过credentials获取配置中的AccessKey ID
        access_key_id="LTAI5tJ9skNA8d1BU1WXJKNv",
        # 通过credentials获取配置中的AccessKey Secret
        access_key_secret="416q30WW0Wv9KBATEUEYtWYDftxqFS"
    )
    # 访问的域名
    config.endpoint = f'docmind-api.cn-hangzhou.aliyuncs.com'
    client = docmind_api20220711Client(config)


    ################提交分析################
    # fileName="23-化产车间(3期)电捕初冷器工岗位规程.pdf"
    # request = docmind_api20220711_models.SubmitDocParserJobAdvanceRequest(
    #     # file_url_object : 本地文件流
    #     file_url_object=open(f"./data/word/{fileName}", "rb"),
    #     file_name=fileName
    # )
    # runtime = util_models.RuntimeOptions()
    # try:
    #     # 复制代码运行请自行打印 API 的返回值
    #     response = client.submit_doc_parser_job_advance(request, runtime)
    #     # API返回值格式层级为 body -> data -> 具体属性。可根据业务需要打印相应的结果。如下示例为打印返回的业务id格式
    #     # 获取属性值均以小写开头，
    #     print(response.body)
    # except Exception as error:
    #     # 如有需要，请打印 error
    #     UtilClient.assert_as_string(error.message)

    
    # ###############查询状态############
    request = docmind_api20220711_models.QueryDocParserStatusRequest(
        # id :  任务提交接口返回的id
        id="docmind-20250102-de35ab8d305e40e6a2ef882d744a7eed"
    )
    try:
        # 复制代码运行请自行打印 API 的返回值
        response = client.query_doc_parser_status(request)
        # API返回值格式层级为 body -> data -> 具体属性。可根据业务需要打印相应的结果。获取属性值均以小写开头
        # 获取返回结果。建议先把response.body.data转成json，然后再从json里面取具体需要的值。
        print(response.body)
    except Exception as error:
        # 如有需要，请打印 error
        UtilClient.assert_as_string(error.message)  

    
    # ################获取结果##################
    request = docmind_api20220711_models.GetDocParserResultRequest(
        # id :  任务提交接口返回的id
        id='docmind-20250102-de35ab8d305e40e6a2ef882d744a7eed',
        layout_step_size=10,
        layout_num=0
    )
    try:
        # 复制代码运行请自行打印 API 的返回值
        response = client.get_doc_parser_result(request)
    except Exception as error:
        # 如有需要，请打印 error
        UtilClient.assert_as_string(error.message) 
    id=getTotalNum()+1
    data = response.body.data
    stringList=[]
    # 提取 output 对象中的 total_doc_count 字段
    for chunk in data['layouts']:
        print(chunk['text'])
        stringList.append(chunk['text'])

    print(stringList)

    
    # stringEmbedding(stringList,total)
    # insertTextEmbedding(collection,0)