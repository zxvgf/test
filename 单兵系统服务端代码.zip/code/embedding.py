import os
import json  
import dashscope
from dashscope import TextEmbedding
from dashscope import MultiModalEmbedding
from dashvector import Client, Doc
import API_KEY
import Header
from API_KEY import API_KEY,VECTOR_API_KEY,ENDPOINT
from Header import PHOTO_COLLECTION_NAME,TEXT_COLLECTION_NAME
from dashtext import SparseVectorEncoder
from dashvector import Doc

photoCollectionName=PHOTO_COLLECTION_NAME
textCollectionName=TEXT_COLLECTION_NAME
def prepare_data(path, batch_size=25):
    batch_docs = []
    for file in os.listdir(path):
        with open(path + '/' + file, 'r', encoding='utf-8') as f:
            batch_docs.append(f.read())
            if len(batch_docs) == batch_size:
                yield batch_docs
                batch_docs = []

    if batch_docs:
        yield batch_docs

# 调用DashScope ONE-PEACE模型，将各种模态素材embedding为向量
def generate_embeddings_photo(text):
    input = []
    if text:
        input.append({'text': text})
    result = MultiModalEmbedding.call(
        model=MultiModalEmbedding.Models.multimodal_embedding_one_peace_v1,
        input=input,
        auto_truncation=True
    )
    print(input,"\n",result)
    if result.status_code != 200:
        raise Exception(f"ONE-PEACE failed to generate embedding of {input}, result: {result}")
    return result.output["embedding"]

def generate_embeddings(news):
    rsp = TextEmbedding.call(
        model=TextEmbedding.Models.text_embedding_v1,
        input=news
    )
    embeddings = [record['embedding'] for record in rsp.output['embeddings']]
    return embeddings if isinstance(news, list) else embeddings[0]


def createHybridCollection(client,collectionName):
    collection_ret=client.get(collectionName)
    print(collection_ret)
    # 解析JSON字符串为Python字典  
    data = json.loads(str(collection_ret))   
    try:
        code_value = data.get('code')
    except Exception as e:
        code_value=0
    if(code_value==-2021):
        print("创建新的数据集合：",collectionName)
        # # 创建集合：指定集合名称和向量维度, text_embedding_v1 模型产生的向量统一为 1536 维
        rsp = client.create(collectionName, dimension=4, metric='dotproduct')
        assert rsp
    else:
        print("新的数据集合已经存在")
    
    return collection_ret
def createCollection(client,collectionName):
    collection_ret=client.get(collectionName)
    print(collection_ret)
    # 解析JSON字符串为Python字典  
    data = json.loads(str(collection_ret))   
    try:
        code_value = data.get('code')
    except Exception as e:
        code_value=0
    if(code_value==-2021):
        print("创建新的数据集合：",collectionName)
        # # 创建集合：指定集合名称和向量维度, text_embedding_v1 模型产生的向量统一为 1536 维
        res = client.create(collectionName, 1536)
        assert res
        return client.get(collectionName)
    else:
        print("新的数据集合已经存在")
    
    return collection_ret

def insertPhotoEmbedding(collection,encoder):
    idy=0
    folder_path="data/img"
    # 遍历文件夹中的所有文件  
    for filename in os.listdir(folder_path):  
        # 检查文件名是否以.txt结尾  
        if filename.endswith(".txt"):  
            # 构建文件的完整路径  
            file_path = os.path.join(folder_path, filename)  
              
            # 尝试打开文件并读取前两行  
            try:  
                with open(file_path, 'r', encoding='utf-8') as file:  
                    lines = []  
                    for _ in range(2):  # 只读取前两行  
                        line = file.readline().strip()  # 读取一行并去除行尾的换行符  
                        if not line:  # 如果读取到空行，则可能已到达文件末尾  
                            break  
                        lines.append(line)  
  
                    if lines:  
                        MSG = lines[0]  
                        URL = lines[1] if len(lines) > 1 else '无第二行内容'  
                        print(f"文件名: {filename}")  
                        print(f"MSG: {MSG}")  
                        print(f"URL: {URL}")  
                        embeddingData=generate_embeddings(MSG)
                        # 向量入库DashVector
                        doc_sparse_vector = encoder.encode_documents(MSG)
                        collection.insert(Doc(
                            id='ID'+str(idy),
                            vector=[0.1, 0.2, 0.3, 0.4],
                            sparse_vector=doc_sparse_vector,
                            fields={'image_url': URL,'msg':MSG}
                        ))
                        idy+=1
                    else:  
                        print(f"文件名: {filename} 是空的")  
                    
            except Exception as e:  
                print(f"读取文件 {file_path} 时发生错误: {e}")   

    
def insertTextEmbedding(collection):
    # # 加载语料
    id = 0
    for news in list(prepare_data('data/text')):
        ids = [id + i for i, _ in enumerate(news)]
        id += len(news)
        
        vectors = generate_embeddings(news)
        # 写入 dashvector 构建索引
        rsp = collection.upsert(
            [
                Doc(id=str(id), vector=vector, fields={"raw": doc})
                for id, vector, doc in zip(ids, vectors, news)
            ]
        )
        assert rsp


if __name__ == '__main__':
    dashscope.api_key = API_KEY
    
    # 初始化 dashvector client
    client = Client(
      api_key=VECTOR_API_KEY,
      endpoint=ENDPOINT
    )
    collection=createHybridCollection(client,photoCollectionName)

    encoder = SparseVectorEncoder()

    # （全部）自有语料
    corpus = Header.CORPUS

    # 基于自有语料训练Encoder
    encoder.train(corpus)
    insertPhotoEmbedding(collection,encoder)

    # collection=createCollection(client,textCollectionName)
    # insertTextEmbedding(collection)
    