from search import initSearch, text_searchPhoto
from answer import *
import answer
from API_KEY import API_KEY
import dashscope, Header
from dashtext import SparseVectorEncoder
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

import json,time
from flask import jsonify
import asyncio
import json
import websockets
from http import HTTPStatus

app = FastAPI()
dashscope.api_key = API_KEY
# STTModel = whisper.load_model("medium")        #medium 20S
collection_photo = initSearch()
encoder = SparseVectorEncoder()
# 基于自有语料训练Encoder
encoder.train(Header.CORPUS)


def textToAnswer(question, image=None, nameList=None, session_id=None):
    head = ""
    result = ""
    try:
        if (nameList):
            result = answer_question(nameList + question, session_id)
        else:
            if (image is not None):
                result =answer_question_img("这是什么", image)
                result = answer_question(result + question, session_id)
            else:
                result = answer_question(question, session_id)
                head = ""
    except Exception as e:
        print(e)
        head = "#error#"
    return result, head


def getContent(data):
    return data["output"]["text"]


def createJson(id, type, answer, status, session_id,questionid,funclist=""):
    data = {
        "id": id,
        "type": type,
        "answer": answer,
        "status": status,
        "session_id": session_id,
        "questionid": questionid,
        "funclist": funclist,
    }
    return data

class Connection:
    def __init__(self,websocket: WebSocket):
        self.websocket=websocket
        self.isclose=1
        self.data_dict=None
    async def receive(self,websocket: WebSocket, client_id: int):
        while(True):
            print("receive")
            response_str =await websocket.receive()
            print("response_str:",response_str)
            self.data_dict=json.loads(response_str['text'])
            isclose=self.data_dict['isclose']
            print("in receive:",isclose)
            if(isclose==0 and self.isclose==0):
                print("wait finish last session...")
                self.isclose=1
                await asyncio.sleep(0.4)
            self.isclose=isclose
            await asyncio.sleep(0.2)
            
    async def send(self):
        while(True):
            if(self.isclose==1):
                await asyncio.sleep(0.1)
                continue
            try:
                question = self.data_dict["question"]
                # 打印问题
                # 获取图片URL
                imageUrl = self.data_dict["image"]
                nameList = self.data_dict["nameList"]
                session_id = self.data_dict["session_id"]
                questionid = self.data_dict["questionid"]
                if (len(session_id) == 0):
                    session_id = None
                myID = 0
                responses = None
                if (len(nameList) > 0):
                    prompt = "用户面前有如下几个物体，之后的问题可能与此有关:" + nameList + " 我的问题是:" + question
                    responses = answer_question(prompt, session_id)
                else:
                    if (len(imageUrl) > 0):
                        print("question:",question," imageUrl:",imageUrl)
                        # 调用大模型，识别图片内容，返回答案
                        responses =answer_question_img(question,imageUrl)
                        # prompt= "图片里有如下几个物体，之后的问题可能与此有关:" + "鼓风机、冷凝器" + " 我的问题是:" + question
                        # responses = answer_question(prompt, session_id)
                        # print(prompt)
                    else:
                        responses = answer_question(question, session_id)
                
                answerF = ""
                for response in responses:
                    if(self.isclose==1):
                        print("fast finish")
                        break
                    print(response.output)
                    session_id = response.output.session_id
                    status = "ok"

                    if response.status_code == HTTPStatus.OK:
                        status = "ok"
                        answerF += response.output.text
                        if("&END" in answerF):
                            funcStr=answerF.split("&END")[0]
                            funcList=funcStr.split("&&&")[1:]
                            data = {
                                "id": myID,
                                "status": "ok",
                                "questionid": questionid,
                                "funclist": funcList,
                            }
                            answerF=answerF.split("&END")[1]
                            print(data)
                            await self.websocket.send_json(data)
                            myID += 1
                            continue
                        if(not '&' in answerF):
                            data = createJson(myID, "answerMsg", answerF, status, session_id,questionid)
                            myID += 1
                            print(data)
                            await self.websocket.send_json(data)
                            answerF=""
                    else:
                        status = "error"
                        print('Request id: %s, Status code: %s, error code: %s, error message: %s' % (
                            response.request_id, response.status_code,
                            response.code, response.message
                        ))
                        data = createJson(-1, "answerMsg", "", status, -1,questionid)
                        await self.websocket.send_json(data)
                    await asyncio.sleep(0.14)  # 避免紧密循环，可以调整为更合适的值
                if(self.isclose==1):
                        print("normal finish session")
                        continue
                photoOut = photoInQuestion(question)
                UrlList = []
                if ("True" in photoOut):
                    print("输出图片")
                    UrlList = text_searchPhoto(question + nameList, collection_photo, encoder)

                data = createJson(myID, "imgUrl", UrlList, "end", session_id,questionid)
                await self.websocket.send_json(data)
                self.isclose=1
            except json.JSONDecodeError as e:
                # 如果 JSON 解析失败，可以处理异常或返回错误响应
                data = {
                    "Error": "Invalid JSON data"
                }
                return jsonify({'status': 'error', 'message': 'Data received'}), 200   

            await asyncio.sleep(0.1)
            

class ConnectionManager:
    def __init__(self):
        self.active_connections: list[Connection] = []

    async def connect(self, websocket: WebSocket,client_id):
        await websocket.accept()
        connection=Connection(websocket)
        try:
            self.active_connections.append(connection)
            print("Connection close and remove from ConnectionList AA num:",len(self.active_connections))
            asyncio.create_task(connection.receive(websocket,client_id))
            await asyncio.create_task(connection.send())
            
            
        except Exception as e:
            print("ConnectionManager ERROR:",e)
            self.disconnect(connection)

    def disconnect(self, websocket:Connection):
        print("Connection close and remove from ConnectionList BB num:",len(self.active_connections))
        if websocket in self.active_connections:
            self.active_connections.remove(websocket)
        print("Connection close and remove from ConnectionList CC num:",len(self.active_connections))



manager = ConnectionManager()
@app.websocket("/llm/{client_id}")
async def websocket_endpoint(websocket: WebSocket, client_id: int):
    await manager.connect(websocket,client_id)

        
if __name__ == '__main__':
    import uvicorn
    # uvicorn.run(app, host="172.25.238.145", port=9008)
    uvicorn.run(app, host="0.0.0.0", port=9008)

