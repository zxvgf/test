import asyncio
import websockets
import json,time

async def client():
    uri = "ws://47.120.12.240:9008/llm/1"
    #https://pic.nximg.cn/file/20230302/34543442_111536872102_2.jpg
    async with websockets.connect(uri) as websocket:
        startTime=time.time()
        message = {"image": "https://pic.nximg.cn/file/20230302/34543442_111536872102_2.jpg",  
                "nameList": "",  
                "question": "图片里是什么",
                "session_id":"",
                "questionid":"312312",
                "isclose":0}
        await websocket.send(json.dumps(message))

        count=0
        # 接收消息并打印
        async for message in websocket:
            print(time.time()-startTime)
            print(f"Received: {message}")
            
        #     if(count>3):
        #         print("break ...")
        #         message = {"isclose":1}
        #         await websocket.send(json.dumps(message))
        #         break
        #     count+=1

        # await asyncio.sleep(0.2)

        # message = {"image": "",  
        #         "nameList": "",  
        #         "question": "成龙是谁",
        #         "session_id":"",
        #         "questionid":"3123212",
        #         "isclose":0}
        # await websocket.send(json.dumps(message))

        # 接收消息并打印
        # async for message in websocket:
        #     print(f"Received: {message}")

# 运行客户端
asyncio.get_event_loop().run_until_complete(client())