import requests  
  
# 目标URL  
url = 'http://47.120.12.240:9007/MeetingAssistant'  # 请替换为你的实际API URL  
  
# 请求体数据  
data = {  
    "question": "小李你今天下午去机房拿一下硬盘，然后去会议室把硬盘里的ppt拷贝到会议室电脑上"  
}  
  
# 发送POST请求  
response = requests.post(url, json=data)  
  
# 检查响应状态码  
if response.status_code == 200:  
    # 假设响应的内容是JSON格式，将其解析为Python字典  
    response_data = response.json()  
      
    # 打印整个响应字典（这应该会直接显示中文）  
    print(response_data['answer'])  
else:  
    # 请求失败，打印错误信息  
    print("请求失败，状态码：", response.status_code, "错误信息：", response.text)