from dashvector import Client
from embedding import generate_embeddings
from API_KEY import VECTOR_API_KEY,ENDPOINT
from Header import PHOTO_COLLECTION_NAME

def initSearch():
    # 初始化 dashvector client
    client = Client(
      api_key=VECTOR_API_KEY,
      endpoint=ENDPOINT
    )
    collection_photo=client.get(PHOTO_COLLECTION_NAME)
    assert collection_photo

    return collection_photo
def search_relevant_news(question,collection):
    # 向量检索：指定 topk = 1 
    rsp = collection.query(generate_embeddings(question), output_fields=['raw'],
                           topk=4)
    assert rsp
    result=""
    maxScore=0
    for i in range(len(rsp.output)):
        result+=rsp.output[i].fields['raw']
        print("raw:",rsp.output[i].fields['raw'])
        score=rsp.output[i].score
        if(score>maxScore):
            maxScore=score
    if(maxScore<0.2 or maxScore>0.95):
        result=""
    print("maxScore:",maxScore)
    return result

def text_searchPhoto(input_text,collection,encoder):
    sparse_vector = encoder.encode_queries(input_text)
    rsp = collection.query(
        vector=[0.1, 0.2, 0.1, 0.1],
        sparse_vector=sparse_vector,
        topk=3
    )
    image_list = list()
    maxScore=0.25
    maxDoc=None
    for doc in rsp:
        try:
          img_url = doc.fields['image_url']
          msg = doc.fields['msg']
          score=doc.score
          if(score>0.5):
              image_list.append(msg+"^"+img_url)
          if(score>maxScore):
              maxDoc=msg+"^"+img_url
              maxScore=score
        except Exception as e:
            continue
    if(len(image_list)==0 and maxDoc is not None):
        image_list.append(maxDoc)
    return image_list